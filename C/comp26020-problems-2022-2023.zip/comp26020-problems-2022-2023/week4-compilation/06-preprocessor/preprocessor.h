#ifndef PREPROCESSOR_H
#define PREPROCESSOR_H

typedef struct timeval tv;

#endif /* PREPROCESSOR_H */
