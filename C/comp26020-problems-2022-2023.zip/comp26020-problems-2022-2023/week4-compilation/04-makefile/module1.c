#include <stdio.h>
#include "module1.h"

void f1(void) {
    printf("f1 called\n");
}
