#ifndef MODULE2_H
#define MODULE2_H

void f2(void);

#endif /* MODULE2_H */
