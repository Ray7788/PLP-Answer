#include <tdio.h>

void man() {
    printf("This should work!\n");
    retur 0;
}
